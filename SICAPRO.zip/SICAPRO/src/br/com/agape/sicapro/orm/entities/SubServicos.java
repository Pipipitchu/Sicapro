package br.com.agape.sicapro.orm.entities;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Sub_Servicos")
public class SubServicos implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="idSubServico")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="subservico_gen")
	@SequenceGenerator (name="subservico_gen", sequenceName="SEQ_SUBSERVICO", allocationSize=1)
	private Integer id;
	
	private String nome;
	private String descricao;
	private Integer prazo;
	private float valor;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy="Sub_Servicos", targetEntity=Servicos.class)
	private Set<Servicos> servico;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Integer getPrazo() {
		return prazo;
	}

	public void setPrazo(Integer prazo) {
		this.prazo = prazo;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

	public Set<Servicos> getServico() {
		return servico;
	}

	public void setServico(Set<Servicos> servico) {
		this.servico = servico;
	}

}
