package br.com.agape.sicapro.orm.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Projetos implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="idProjeto")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="projeto_gen")
	@SequenceGenerator (name="projeto_gen", sequenceName="SEQ_PROJETO", allocationSize=1)
	private Integer id;
	
	private Date data;
	private float valor;
	private String descricao;
	
	@ManyToOne
	@JoinColumn(name="idStatus", nullable= false)
	private Status status;
	
	@ManyToOne
	@JoinColumn(name="idOrcamento", nullable= false)
	private Orcamentos orcamento;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Orcamentos getOrcamento() {
		return orcamento;
	}

	public void setOrcamento(Orcamentos orcamento) {
		this.orcamento = orcamento;
	}
	
	
}
