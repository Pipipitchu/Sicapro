package br.com.agape.sicapro.orm.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
public class Orcamentos implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="idOrcamento")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="orcamento_gen")
	@SequenceGenerator (name="orcamento_gen", sequenceName="SEQ_ORCAMENTO", allocationSize=1)
	private Integer id;
	
	private Date data;
	private float valor;
	private String comentario;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy="Orcamentos", targetEntity=Projetos.class)
	private Set<Projetos> projeto;
	
	@ManyToOne
	@JoinColumn(name="idFuncionario", nullable= false)
	private Funcionario funcionario;
	
	@ManyToOne
	@JoinColumn(name="idStatus", nullable= false)
	private Status status;
	
	@ManyToOne
	@JoinColumn(name="idCliente", nullable= false)
	private Clientes cliente;
	
	@ManyToOne
	@JoinColumn(name="idServico", nullable= false)
	private Servicos servico;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public float getValor() {
		return valor;
	}

	public void setValor(float valor) {
		this.valor = valor;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	public Set<Projetos> getProjeto() {
		return projeto;
	}

	public void setProjeto(Set<Projetos> projeto) {
		this.projeto = projeto;
	}

	public Funcionario getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public Clientes getCliente() {
		return cliente;
	}

	public void setCliente(Clientes cliente) {
		this.cliente = cliente;
	}

	public Servicos getServico() {
		return servico;
	}

	public void setServico(Servicos servico) {
		this.servico = servico;
	}

}
