package br.com.agape.sicapro.orm.entities;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Funcionarios")
public class Funcionario implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="idFuncionario")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="funcionario_gen")
	@SequenceGenerator (name="funcionario_gen", sequenceName="SEQ_FUNCIONARIO", allocationSize=1)
	private Integer id;
	
	private String nome;
	private String endereco;
	private String numero;
	private String bairro;
	private String cidade;
	private String cep;
	private String uf;
	private String telefone;
	private String celular;
	private String email;
	private String dataCadastro;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy="Funcionarios", targetEntity=Lancamentos.class)
	private Set<Lancamentos> lancamento;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy="Funcionarios", targetEntity=Orcamentos.class)
	private Set<Orcamentos> orcamento;
	
	@ManyToOne
	@JoinColumn(name="idTipoFuncionario", nullable= false)
	private TipoFuncionario tipoFuncionario;
	
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getEndereco() {
		return endereco;
	}

	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}

	public String getNumero() {
		return numero;
	}

	public void setNumero(String numero) {
		this.numero = numero;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		this.bairro = bairro;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		this.cidade = cidade;
	}

	public String getCep() {
		return cep;
	}

	public void setCep(String cep) {
		this.cep = cep;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		this.uf = uf;
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getCelular() {
		return celular;
	}

	public void setCelular(String celular) {
		this.celular = celular;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDataCadastro() {
		return dataCadastro;
	}

	public void setDataCadastro(String dataCadastro) {
		this.dataCadastro = dataCadastro;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public TipoFuncionario getTipoFuncionario() {
		return tipoFuncionario;
	}

	public void setTipoFuncionario(TipoFuncionario tipoFuncionario) {
		this.tipoFuncionario = tipoFuncionario;
	}
	
	public Set<Lancamentos> getLancamentos() {
		return lancamento;
	}

	public void setLancamentos(Set<Lancamentos> lancamento) {
		this.lancamento = lancamento;
	}
	
}
