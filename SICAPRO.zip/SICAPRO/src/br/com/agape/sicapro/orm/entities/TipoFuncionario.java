package br.com.agape.sicapro.orm.entities;

import java.io.Serializable;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Tipo_Funcionarios")
public class TipoFuncionario implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="idTipoFuncionario")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="tipofuncionario_gen")
	@SequenceGenerator (name="tipofuncionario_gen", sequenceName="SEQ_TIPOFUNCIONARIO", allocationSize=1)
	private Integer id;
	
	private String cargo;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy="Tipos_Funcionarios", targetEntity=Funcionario.class)
	private Set<Funcionario> funcionario;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}
}
