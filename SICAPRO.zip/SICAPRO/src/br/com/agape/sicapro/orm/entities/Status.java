package br.com.agape.sicapro.orm.entities;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;

@Entity
public class Status implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="idStatus")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="status_gen")
	@SequenceGenerator (name="status_gen", sequenceName="SEQ_STATUS", allocationSize=1)
	private Integer id;
	
	private String nome;
	private String descricao;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy="Status", targetEntity=Orcamentos.class)
	private Set<Orcamentos> orcamento;
	
	@OneToMany(fetch = FetchType.LAZY, mappedBy="Status", targetEntity=Projetos.class)
	private Set<Projetos> projeto;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public Set<Orcamentos> getOrcamento() {
		return orcamento;
	}

	public void setOrcamento(Set<Orcamentos> orcamento) {
		this.orcamento = orcamento;
	}

	public Set<Projetos> getProjeto() {
		return projeto;
	}

	public void setProjeto(Set<Projetos> projeto) {
		this.projeto = projeto;
	}
	

}
