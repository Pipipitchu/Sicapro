package br.com.agape.sicapro.orm.entities;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Compromissos implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name="idCompromisso")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="compromisso_gen")
	@SequenceGenerator (name="compromissso_gen", sequenceName="SEQ_COMPROMISSO", allocationSize=1)
	private Integer id;
	
	private Date data;
	private String hora;
	private String comentario;
	
	@ManyToOne
	@JoinColumn(name="idCliente", nullable= false)
	private Clientes cliente;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getData() {
		return data;
	}

	public void setData(Date data) {
		this.data = data;
	}

	public String getHora() {
		return hora;
	}

	public void setHora(String hora) {
		this.hora = hora;
	}

	public String getComentario() {
		return comentario;
	}

	public void setComentario(String comentario) {
		this.comentario = comentario;
	}

	public Clientes getCliente() {
		return cliente;
	}

	public void setCliente(Clientes cliente) {
		this.cliente = cliente;
	}

}
